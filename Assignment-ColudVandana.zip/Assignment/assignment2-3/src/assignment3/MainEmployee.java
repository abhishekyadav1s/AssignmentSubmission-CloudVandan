package assignment3;

import assignment3.model.Employees;

import java.util.ArrayList;
import java.util.List;

public class MainEmployee {
    public static void main(String[] args) {
        //Create Employees
        Employees employees1  = new Employees(1,"Abhishek",20000);
        Employees employees2 = new Employees(2,"Rishabh",25000);
        Employees employees3 = new Employees(3,"Sumit",30000);


        List<Employees> employeesList = new ArrayList<>();
        employeesList.add(employees1);
        employeesList.add(employees2);
        employeesList.add(employees3);

        for(Employees employees : employeesList){
            employees.displayDetails();
        }
    }




}
